// Reviewer-authored, fixed-snapshot normal-command witness. Run only in the
// coordinated isolated ordinary clone, never in the author's working tree.
use crate::{model::*, unit_support::*};

#[test]
fn independent_wm057_wm025_simultaneous_win_must_offer_controller_order() {
    let mut g = game();
    let broker = field(&mut g, "WM057", 0);
    field(&mut g, "WM025", 0);
    fund(&mut g, 0, "JC125", 2);
    let shown = [held(&mut g, "WM025", 0), held(&mut g, "WM025", 1),
        held(&mut g, "JC125", 2), held(&mut g, "JC125", 3)];
    act(&mut g, 0, Action { card_id: Some(broker),
        ability_id: Some(crate::import20_broker::ACT.into()), ..Action::new("activate") });
    crate::jc029_tests::pass_top(&mut g);
    for seat in 0..4 {
        assert_eq!(g.pending.as_ref().unwrap().choice.kind, crate::mystic_contest::COMMIT_KIND);
        assert_eq!(g.pending.as_ref().unwrap().seat, seat);
        choose(&mut g, vec![shown[seat].clone()]);
    }
    assert_eq!(g.mystic_history.last().unwrap().winner_team, Some(0));
    while g.pending.as_ref().is_some_and(|p| p.choice.kind == crate::mystic_contest::REWARD_KIND) {
        choose(&mut g, vec![]);
    }
    let p = g.pending.as_ref().expect("first simultaneous win declaration");
    assert_eq!(p.seat, 0);
    let first = match &p.resolution { ChoiceResolution::Declare { declaration, .. } => Some(declaration.ability.key.clone()), _ => None };
    let vampire_queued = g.effects.iter().any(|e| matches!(e,
        Effect::Declare { declaration } if declaration.actor == 0
            && declaration.ability.key == crate::import20_vampires::WIN));
    println!("Same controller won one actual paid mystic contest: pending={}, first={first:?}, WM025queued={vampire_queued}, orderGroups={}",p.choice.kind,g.entry_order_groups.len());
    assert_eq!(p.choice.kind, "batch3-entry-order", "controller must choose which simultaneous win trigger enters stack next");
    assert_eq!(p.choice.options.len(),2);
    restore(&mut g);
}
