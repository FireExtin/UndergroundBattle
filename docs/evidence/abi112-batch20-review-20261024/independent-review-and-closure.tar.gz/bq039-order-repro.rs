// Independent normal paid-attachment -> combat witness for fixed91ae.
use crate::{model::*, unit_support::*};

#[test]
fn independent_two_paid_bq039_battle_wins_must_offer_controller_order() {
    let mut g = game();
    let host = field(&mut g, "JC084", 0);
    field(&mut g, "JC084", 0);
    let enemy = field(&mut g, "JC084", 2);
    held(&mut g, "JC125", 2);
    held(&mut g, "JC125", 3);
    fund(&mut g, 0, "JC029", 2); // Actual two-blue loyalty and two paid assets.
    for expected_remaining in [1, 0] {
        let source = held(&mut g, "BQ039", 0);
        act(&mut g, 0, Action { card_id: Some(source), target_id: Some(host.clone()), ..Action::new("play") });
        let f = g.stack.last().unwrap().frame.as_ref().unwrap();
        assert_eq!(f.money_units(0), 1);
        assert_eq!(g.resources(0), expected_remaining);
        crate::jc029_tests::pass_top(&mut g);
    }
    assert_eq!(g.attachments.iter().filter(|a| a.card.definition == "BQ039" && a.host_id == host).count(), 2);
    g.begin_window(Window::Before(0, 1));
    assert_eq!(g.contest_counts(0, 1), [2, 1]);
    for _ in 0..4 { pass(&mut g); }
    for _ in 0..16 {
        if let Some(p) = g.pending.clone() {
            if matches!(p.resolution, ChoiceResolution::Damage { .. }) {
                act(&mut g, p.seat, Action { choice_id: Some(p.choice.id),
                    allocations: Some([(enemy.clone(), p.choice.amount.unwrap())].into()), ..Action::new("choose") });
            } else { break; }
        } else if !g.stack.is_empty() { pass(&mut g); }
        else { g.drive().unwrap(); }
    }
    let p = g.pending.as_ref().expect("two actual host-battle triggers");
    let first = match &p.resolution { ChoiceResolution::Declare { declaration, .. } => Some(declaration.ability.key.clone()), _ => None };
    let remaining = g.effects.iter().filter(|e| matches!(e,
        Effect::Declare { declaration } if declaration.actor == 0
            && declaration.ability.key == crate::import20_observers::EYE_WIN)).count();
    println!("Two actual paid BQ039 attachments, real combat2:1 won: pending={}, first={first:?}, remainingEye={remaining}, orderGroups={}",p.choice.kind,g.entry_order_groups.len());
    assert_eq!(p.seat, 0);
    assert_eq!(p.choice.kind, "batch3-entry-order", "same controller must order simultaneous BQ039 battle triggers");
    assert_eq!(p.choice.options.len(),2);
}
