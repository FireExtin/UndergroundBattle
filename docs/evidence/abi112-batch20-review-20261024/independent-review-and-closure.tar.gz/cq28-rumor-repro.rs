// Independent, reviewer-authored probe for fixed HEAD 91ae5336.
// To run only after coordination: include as a cfg(test) module in an isolated
// ordinary clone. This file does not change production code or author tests.
use crate::{model::*, unit_support::*};

fn legal_mill_reaches_rumor(second: u8) {
        let mut g = game();
        fund(&mut g, 0, "WM057", 4);
        field(&mut g, "JC125", 0); // A legal, public rumor sealing target.
        g.players[0].deck.clear();
        for definition in ["WM042", "JC125", "JC084", "JC014", "JC085", "JC042", "JC112"] {
            let c = g.make_card(definition, 0);
            g.players[0].deck.push(c);
        }
        let original_top = g.players[0].deck[0].id.clone();
        let gate = held(&mut g, "CQ28", 0);
        act(&mut g, 0, Action { card_id: Some(gate), ..Action::new("play") });
        choose(&mut g, vec!["item-0".into()]);
        choose(&mut g, vec![format!("item-{second}")]);
        assert_eq!(g.players[0].assets.iter().filter(|c| c.exhausted).count(), 4);
        let mut observed = false;
        for _ in 0..32 {
            let seat = (0..4).find(|s| g.legal_actions(*s).iter().any(|a| a.action.kind == "pass"))
                .expect("normal public response pass");
            let before = serde_json::to_string(&g).unwrap();
            match g.apply(seat, Action::new("pass")) {
                Ok(()) => {
                    if let Some(p) = &g.pending {
                        assert!(matches!(p.resolution, ChoiceResolution::Rumor { .. }));
                        observed = true;
                        break;
                    }
                    assert!(!g.stack.is_empty(), "mill must offer the legal rumor replacement");
                }
                Err(error) => {
                    assert_eq!(error, "传闻原效应不能产生该区域转移批次");
                    assert_eq!(serde_json::to_string(&g).unwrap(), before, "rejected pass must be atomic");
                    assert_eq!(g.players[0].deck[0].id, original_top);
                    assert!(g.pending.is_none());
                    assert_eq!(g.stack.len(), 1);
                    panic!("CQ28 pair 0,{second}: legal final public pass must reach rumor choice; observed error={error}; paid4 retained; rejected state unchanged");
                }
            }
        }
        assert!(observed, "legal rumor choice must be reachable");
}

#[test]
fn independent_cq28_rumor_pair00_public_pass_must_reach_rumor() { legal_mill_reaches_rumor(0); }

#[test]
fn independent_cq28_rumor_pair03_public_pass_must_reach_rumor() { legal_mill_reaches_rumor(3); }

#[test]
fn independent_cq28_rumor_without_eligible_host_control_completes() {
    let mut g = game();
    fund(&mut g, 0, "WM057", 4);
    g.players[0].deck.clear();
    for definition in ["WM042", "JC125", "JC084", "JC014", "JC085", "JC042", "JC112"] {
        let c = g.make_card(definition, 0);
        g.players[0].deck.push(c);
    }
    let gate = held(&mut g, "CQ28", 0);
    act(&mut g, 0, Action { card_id: Some(gate), ..Action::new("play") });
    choose(&mut g, vec!["item-0".into()]);
    choose(&mut g, vec!["item-3".into()]);
    crate::jc029_tests::pass_top(&mut g);
    assert!(g.pending.is_none() && g.stack.is_empty());
    assert_eq!(g.players[0].hand.len(), 1);
    assert_eq!(g.players[0].hand[0].definition, "JC112");
    restore(&mut g);
}
