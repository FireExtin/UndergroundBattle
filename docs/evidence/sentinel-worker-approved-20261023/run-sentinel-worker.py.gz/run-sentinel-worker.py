import os,subprocess,json,hashlib,sys,time
from pathlib import Path
root=Path.cwd();r=root/'UndergroundBattle-blue-gray';name=sys.argv[1];log=root/'verification'/f'{name}.log';assert not log.exists();os.sched_setaffinity(0,[29]);os.nice(19)
env=dict(os.environ);env.pop('NODE_TEST_CONTEXT',None);env.pop('NODE_OPTIONS',None);env.update(SENTINEL_NODE_MODULES='/home/ddd/Documents/Codex/2026-10-21/task-3/UndergroundBattle-batch4/sites/node_modules',SENTINEL_WORKER_DIR=str(root/'worker-sentinel-local'),SENTINEL_WORKER_WITNESSES=':'.join(str(root/'verification'/n) for n in ['sentinel-worker-witness.json','sentinel-worker-move-witness.json']))
cmd=['/home/ddd/Documents/Codex/2026-10-21/task-3/.tools/node-v24.22.1-linux-x64/bin/node','--test','--test-isolation=none','sites/test/sentinel-local-worker.test.mjs'];start=time.monotonic()
with log.open('x') as f:result=subprocess.run(cmd,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
d={'command':cmd,'exitCode':result.returncode,'seconds':time.monotonic()-start,'cpu':29,'nice':19,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()};(root/'verification'/f'{name}.json').write_text(json.dumps(d,indent=2));print(json.dumps(d));sys.exit(result.returncode)
