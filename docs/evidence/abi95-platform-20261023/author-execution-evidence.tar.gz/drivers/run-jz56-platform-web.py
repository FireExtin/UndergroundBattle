from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path(__file__).resolve().parent;r=root/'UndergroundBattle-batch4';work=root/'jz56-platform-web-20261023';work.mkdir(exist_ok=True)
name,*args=sys.argv[1:];log=work/(name+'.log');receipt=work/(name+'.json');assert not log.exists() and not receipt.exists()
env=dict(os.environ);env.update(PATH=str(root/'.tools/node-v24.22.1-linux-x64/bin')+':'+env['PATH'],NODE_OPTIONS='--max-old-space-size=4096',NPM_CONFIG_OFFLINE='true',WRANGLER_SEND_METRICS='false')
env['HEGEMONY_WASM_TEST_ABI']=(r/'rust-game-wasm/pkg/hegemony_wasm.js').as_uri()
os.sched_setaffinity(0,[max(os.sched_getaffinity(0))]);os.nice(19)
inputs=[*sorted((r/'web/src').rglob('*')),*[r/p for p in ['web/package.json','web/package-lock.json','web/vite.config.ts','web/tsconfig.app.json','web/tsconfig.node.json']]]
data=dict(command=args,cwd=str(r/'web'),sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),worktree=subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True),startUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),state='running',cpu=list(os.sched_getaffinity(0)),nice=19,network='offline dependency cache; no install',nodeVersion=subprocess.check_output(['node','--version'],env=env,text=True).strip(),sourceFiles=[dict(path=str(p.relative_to(r)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in inputs if p.is_file()])
receipt.write_text(json.dumps(data,indent=2)+'\n');start=time.monotonic()
with log.open('x') as out: result=subprocess.run(args,cwd=r/'web',env=env,stdout=out,stderr=subprocess.STDOUT)
data.update(state='complete',exitCode=result.returncode,seconds=round(time.monotonic()-start,3),logSha256=hashlib.sha256(log.read_bytes()).hexdigest());receipt.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({k:data[k] for k in ['state','exitCode','seconds','logSha256']}));sys.exit(result.returncode)
