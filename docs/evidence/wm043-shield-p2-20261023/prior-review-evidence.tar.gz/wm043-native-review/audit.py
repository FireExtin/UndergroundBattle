#!/usr/bin/env python3
"""Read fixed Git objects and author receipts; does not execute product tests."""
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / "UndergroundBattle-wm043-review"
BASE = "5607a1c06f00920a0d927958975e1a34e31df2f8"
SOURCE = "0a3122adfb5fa7d74fe6721287c48d50a384da59"
FINAL = "96a5de6030cd3b207b96994638300956f77030a0"
PREFIX = "docs/evidence/wm043-native-20261023/"

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)

def blob(path, revision=FINAL):
    return git("show", f"{revision}:{path}")

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest = json.loads(blob(PREFIX + "manifest.json"))
manifest_results = [{"path": x["path"], "matches": sha(blob(x["path"])) == x["sha256"]}
                    for x in manifest]
verification = json.loads(blob(PREFIX + "verification.json"))
all_passed = set()
runs = []
compile_paths = set(git("ls-tree", "-r", "--name-only", FINAL, "rust-game/src").decode().splitlines())
compile_paths |= {"Cargo.toml", "Cargo.lock", "rust-game/Cargo.toml", "rust-game/data/cards.json"}
for expected in verification["nativeRuns"]:
    name = expected["name"]
    record = json.loads(gzip.decompress(blob(PREFIX + "runs/" + name + ".json.gz")))
    raw_log = gzip.decompress(blob(PREFIX + "runs/" + name + ".log.gz"))
    text = raw_log.decode()
    passed = re.findall(r"^test (\S+) \.\.\. ok$", text, re.M)
    counts = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;", text)
    recorded = {x["path"]: x["sha256"] for x in record["sourceFiles"]}
    mismatches = [p for p, h in recorded.items() if sha(blob(p)) != h]
    all_passed.update(passed)
    runs.append({
        "name": name, "sourceHeadAtRun": record["sourceHead"],
        "exitCode": record["exitCode"], "counts": counts,
        "testNamesPassed": passed, "matchesDeclaredCount": len(passed) == expected["passed"],
        "logHashMatchesReceipt": sha(raw_log) == record["logSha256"],
        "logHashMatchesVerification": sha(raw_log) == expected["logSha256"],
        "recordedSourceFiles": len(recorded),
        "missingRustOrBuildInputs": sorted(compile_paths - set(recorded)),
        "sourceHashMismatchesAgainstFixedFinal": mismatches,
    })
    (ROOT / (name + "-author.json")).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    (ROOT / (name + "-author.log")).write_bytes(raw_log)

source_log = gzip.decompress(blob(PREFIX + "runs/source-03.log.gz"))
(ROOT / "source-03-author.log").write_bytes(source_log)
baseline_pool = json.loads(blob("rust-game/data/cards.json", BASE))
final_pool = json.loads(blob("rust-game/data/cards.json"))
new_card = [c for c in final_pool["cards"] if c["id"] == "WM043"]
without_wm043 = dict(final_pool, cards=[c for c in final_pool["cards"] if c["id"] != "WM043"])
image_path = "resource/ymsj-fun.github.io/cards/WM043 精准打击.jpg"
bundle = Path("/home/ddd/Documents/Codex/2026-10-23/task-7/wm043-native-candidate.bundle")
runtime_changes = git("diff", "--name-only", BASE, SOURCE, "rust-game").decode().splitlines()
after_runtime_changes = git("diff", "--name-only", SOURCE, FINAL, "rust-game").decode().splitlines()
source_proofs = {
    "originalImageSha256": sha(blob(image_path)),
    "publicImageSha256": sha(blob("web/public/cards/WM043.jpg")),
    "imageEquality": blob(image_path) == blob("web/public/cards/WM043.jpg"),
    "hegemonyRulesSha256": sha(blob("resource/ymsj-fun.github.io/public/docs/霸权说明书.pdf")),
    "veilRulesSha256": sha(blob("resource/ymsj-fun.github.io/public/docs/帷幕之后说明书.jpg")),
    "baseRulesSha256": sha(blob("resource/ymsj-fun.github.io/public/docs/隐秘世界规则手册.pdf")),
    "bundleSha256": sha(bundle.read_bytes()),
    "catalogOnlyAddsWM043": baseline_pool == without_wm043,
    "newCardCount": len(new_card), "supported": new_card[0]["supported"],
    "unchangedDependencies": {
        p: blob(p, BASE) == blob(p) for p in ["rust-game/src/sentinel.rs", "rust-game/src/batch4_intelligence.rs",
            "docs/factions/card-specifications.json", "docs/factions/batch20-fourth-2026-10-22.json"]
    },
}
report = {
    "base": BASE, "runtimeSource": SOURCE, "delivery": FINAL,
    "auditKind": "independent read-only source and author-evidence audit; not own test execution",
    "manifest": manifest_results, "runs": runs,
    "authorUniqueNativePassed": len(all_passed),
    "testNameSetMatchesVerification": all_passed == set(verification["tests"]),
    "authorSourceLogHashMatches": sha(source_log) == verification["sourceChecks"]["logSha256"],
    "authorSourceLogSummary": source_log.decode().splitlines()[-12:],
    "sourceProofs": source_proofs,
    "runtimeChanges": runtime_changes, "postRuntimeRustChanges": after_runtime_changes,
    "ownRuntimeTestsExecutedByThisAudit": 0,
    "resourceHold": "Do not start a new heavy build on CPU 30/31 until coordination clears the performance window.",
}
(ROOT / "author-and-source-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
assert all(x["matches"] for x in manifest_results)
assert all(x["logHashMatchesReceipt"] and x["logHashMatchesVerification"] and x["matchesDeclaredCount"]
           and not x["missingRustOrBuildInputs"] and not x["sourceHashMismatchesAgainstFixedFinal"] for x in runs)
assert len(all_passed) == 131 and all_passed == set(verification["tests"])
assert report["authorSourceLogHashMatches"] and source_proofs["catalogOnlyAddsWM043"]
assert source_proofs["imageEquality"] and all(source_proofs["unchangedDependencies"].values())
print(json.dumps({"manifestFilesVerified": len(manifest_results), "boundNativeRuns": len(runs),
                  "authorUniqueNativePassed": len(all_passed), "ownRuntimeTestsExecutedByThisAudit": 0,
                  "sourceProofs": source_proofs}, ensure_ascii=False, indent=2))
