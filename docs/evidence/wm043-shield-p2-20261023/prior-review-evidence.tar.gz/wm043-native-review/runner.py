#!/usr/bin/env python3
"""One low-priority, offline test-filter run; all mutable caches stay in task-2."""
import datetime
import json
import hashlib
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = root / "UndergroundBattle-wm043-review"
evidence = root / "wm043-native-review"
evidence.mkdir(exist_ok=True)
attempt = sys.argv[1] if len(sys.argv) > 1 else "attempt-1"
toolchain = Path("/home/ddd/Documents/Codex/2026-10-21/task-3/.tools/rustup/toolchains/1.90.0-x86_64-unknown-linux-gnu/bin")
toolroot = toolchain.parents[3]
cpu = 30
assert cpu in os.sched_getaffinity(0), "coordinated CPU unavailable"
env = os.environ.copy()
env.update({
    "PATH": str(toolchain) + os.pathsep + env["PATH"],
    "CARGO_HOME": str(root / "recovery-runtime/cargo"),
    "CARGO_TARGET_DIR": str(root / "recovery-build/target"),
    "RUSTC": str(toolchain / "rustc"),
    "RUSTDOC": str(toolchain / "rustdoc"),
    "CARGO_NET_OFFLINE": "true",
    "CARGO_BUILD_JOBS": "1",
    "CARGO_INCREMENTAL": "0",
    "CARGO_PROFILE_TEST_DEBUG": "0",
    "CARGO_PROFILE_TEST_CODEGEN_UNITS": "16",
    "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER": str(toolroot / "zig-cc"),
    "CC": str(toolroot / "batch3-zig-cc"),
    "ZIG_GLOBAL_CACHE_DIR": str(root / "recovery-build/zig-global"),
    "ZIG_LOCAL_CACHE_DIR": str(root / "recovery-build/zig-local"),
    "TMPDIR": str(root / "recovery-build/tmp"),
    "RAYON_NUM_THREADS": "1",
    "GIT_OPTIONAL_LOCKS": "0",
    "INDEPENDENT_HISTORY_OUT": str(evidence / (attempt + "-traces")),
})
# Author fixture exporters are intentionally not enabled by this test line.
for key in ("HEGEMONY_RECOVERY_FIXTURE_DIR", "GREEN_EVIDENCE_DIR", "JC029_EVIDENCE_DIR"):
    env.pop(key, None)
command = [str(toolchain / "cargo"), "test", "--offline", "--locked", "-j", "1",
           "-p", "hegemony-server", "--no-default-features", "--lib"]
command.extend(["--", "--test-threads=1", "--nocapture"])
command.extend(sys.argv[2:])

def limit_resources():
    os.setsid()
    os.nice(19)
    os.sched_setaffinity(0, {cpu})
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
logpath = evidence / f"{attempt}.log"
assert not logpath.exists(), "never overwrite an earlier run"
print(json.dumps({"started": started, "command": command, "cpu": cpu,
                  "nice": 19, "address_space_cap_bytes_per_process": 8 * 1024**3,
                  "log": str(logpath)}), flush=True)
source_paths = subprocess.check_output(["git", "ls-files", "rust-game/src", "rust-game/data", "Cargo.lock", "Cargo.toml", "rust-game/Cargo.toml"], cwd=repo, text=True).splitlines()
input_record = {"sourceCommit": subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip(),
    "worktree": subprocess.check_output(["git","status","--porcelain"],cwd=repo,text=True),
    "files": [{"path":p,"sha256":hashlib.sha256((repo/p).read_bytes()).hexdigest()} for p in source_paths]}
(evidence / f"{attempt}-inputs.json").write_text(json.dumps(input_record,indent=2)+"\n")
with logpath.open("w") as log:
    process = subprocess.Popen(["ionice", "-c", "3", *command], cwd=repo, env=env,
                               stdout=log, stderr=subprocess.STDOUT,
                               preexec_fn=limit_resources)
    timed_out = False
    try:
        returncode = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        import signal
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            returncode = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            returncode = process.wait()
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
result = {"started": started, "ended": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "command": command, "cwd": str(repo), "returncode": returncode,
          "timed_out": timed_out, "wall_seconds": round(time.monotonic() - start, 3),
          "children_user_seconds": usage.ru_utime, "children_system_seconds": usage.ru_stime,
          "max_child_rss_kib": usage.ru_maxrss, "cpu": cpu, "nice": 19,
          "address_space_cap_bytes_per_process": 8 * 1024**3,
          "cargo_jobs": 1, "test_threads": 1, "io_class": "idle", "log": str(logpath)}
(evidence / f"{attempt}.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
print(logpath.read_text()[-15000:], flush=True)
sys.exit(returncode if returncode >= 0 else 1)
